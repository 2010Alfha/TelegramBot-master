# TelegramBot
Deprecated!

Most work will now be on the [.NET Core 1.0 Version](https://github.com/ScottRFrost/TrixieBot)

A simple C# console application bot for Telegram implementing [Telegram.bot](https://github.com/MrRoundRobin/telegram.bot)
by [MrRoundRobin](https://github.com/MrRoundRobin)
